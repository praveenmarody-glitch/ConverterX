import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';
import '../constants/app_strings.dart';
import '../utils/helpers.dart';
import '../widgets/language_selector.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final provider = context.watch<ThemeProvider>();
    final s = provider.isKannada;

    return Scaffold(
      appBar: AppBar(
        title: Text(s ? AppStrings.settingsKn : AppStrings.settings),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Appearance Section
          _SectionHeader(
            title: s ? 'ಗೋಚರತೆ' : 'Appearance',
            icon: Icons.palette_outlined,
          ),
          
          // Dark Mode Toggle
          Card(
            child: SwitchListTile(
              secondary: Icon(
                provider.isDarkMode ? Icons.dark_mode : Icons.light_mode,
                color: theme.colorScheme.primary,
              ),
              title: Text(s ? AppStrings.darkModeKn : AppStrings.darkMode),
              subtitle: Text(
                provider.isDarkMode
                  ? (s ? 'ಡಾರ್ಕ್ ಥೀಮ್ ಸಕ್ರಿಯ' : 'Dark theme active')
                  : (s ? 'ಲೈಟ್ ಥೀಮ್ ಸಕ್ರಿಯ' : 'Light theme active'),
              ),
              value: provider.isDarkMode,
              onChanged: (_) => provider.toggleTheme(),
            ),
          ),
          
          const SizedBox(height: 8),
          
          // Language Selector
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(
                        Icons.language,
                        color: theme.colorScheme.primary,
                      ),
                      const SizedBox(width: 12),
                      Text(
                        s ? AppStrings.languageKn : AppStrings.language,
                        style: theme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  const LanguageSelector(),
                ],
              ),
            ),
          ),
          
          const SizedBox(height: 24),
          
          // About Section
          _SectionHeader(
            title: s ? 'ಬಗ್ಗೆ' : 'About',
            icon: Icons.info_outline,
          ),
          
          Card(
            child: Column(
              children: [
                ListTile(
                  leading: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: theme.colorScheme.primaryContainer,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(
                      Icons.app_shortcut,
                      color: theme.colorScheme.onPrimaryContainer,
                    ),
                  ),
                  title: Text(s ? AppStrings.appNameKn : AppStrings.appName),
                  subtitle: Text(s ? AppStrings.versionKn : AppStrings.version),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.code),
                  title: Text(s ? 'ಮೂಲ ಕೋಡ್' : 'Source Code'),
                  subtitle: Text(s ? 'GitHub ನಲ್ಲಿ ವೀಕ್ಷಿಸಿ' : 'View on GitHub'),
                  trailing: const Icon(Icons.open_in_new),
                  onTap: () {
                    Helpers.launchUrl('https://github.com');
                  },
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.help_outline),
                  title: Text(s ? 'ಸಹಾಯ' : 'Help'),
                  subtitle: Text(s ? 'ಸಹಾಯ ಕೇಂದ್ರ' : 'Help Center'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () {
                    _showHelpDialog(context);
                  },
                ),
              ],
            ),
          ),
          
          const SizedBox(height: 24),
          
          // Test Phrase (from memory)
          Card(
            color: theme.colorScheme.secondaryContainer.withOpacity(0.5),
            child: ListTile(
              leading: Icon(
                Icons.favorite,
                color: theme.colorScheme.secondary,
              ),
              title: Text(
                s ? 'ಪ್ರೋತ್ಸಾಹ' : 'Encouragement',
                style: TextStyle(
                  color: theme.colorScheme.onSecondaryContainer,
                  fontWeight: FontWeight.bold,
                ),
              ),
              subtitle: Text(
                s ? AppStrings.greatKn : AppStrings.great,
                style: TextStyle(
                  color: theme.colorScheme.onSecondaryContainer,
                ),
              ),
            ),
          ),
          
          const SizedBox(height: 32),
          
          // Footer
          Center(
            child: Text(
              '© 2026 ConverterX\n${s ? 'ಎಲ್ಲಾ ಹಕ್ಕುಗಳು ಕಾಯ್ದಿರಿಸಲಾಗಿವೆ' : 'All rights reserved'}',
              textAlign: TextAlign.center,
              style: theme.textTheme.bodySmall?.copyWith(
                color: theme.colorScheme.onSurface.withOpacity(0.5),
              ),
            ),
          ),
          
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  void _showHelpDialog(BuildContext context) {
    final provider = context.read<ThemeProvider>();
    final s = provider.isKannada;
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(s ? 'ಸಹಾಯ' : 'Help'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _HelpItem(
                icon: Icons.language,
                title: s ? 'ವೆಬ್ ಟು ಆ್ಯಪ್' : 'Web to App',
                description: s
                  ? 'ಯಾವುದೇ ವೆಬ್ಸೈಟ್‌ನ್ನು ಆ್ಯಪ್‌ ಆಗಿ ಪರಿವರ್ತಿಸಿ. URL, ಆ್ಯಪ್ ಹೆಸರು, ಮತ್ತು ಐಕಾನ್ ಸೆಟ್ ಮಾಡಿ.'
                  : 'Convert any website to an app. Set URL, app name, and icon.',
              ),
              const SizedBox(height: 16),
              _HelpItem(
                icon: Icons.swap_horiz,
                title: s ? 'APK/AAB ಪರಿವರ್ತಕ' : 'APK/AAB Converter',
                description: s
                  ? 'APK ಮತ್ತು AAB ಫಾರ್ಮ್ಯಾಟ್‌ಗಳ ನಡುವೆ ಪರಿವರ್ತಿಸಿ. bundletool ಅಗತ್ಯವಿದೆ.'
                  : 'Convert between APK and AAB formats. Requires bundletool.',
              ),
              const SizedBox(height: 16),
              _HelpItem(
                icon: Icons.terminal,
                title: s ? 'ಟರ್ಮಕ್ಸ್ ಬಳಸಿ' : 'Use Termux',
                description: s
                  ? 'ನಿಜವಾದ APK ನಿರ್ಮಾಣಕ್ಕಾಗಿ ಟರ್ಮಕ್ಸ್‌ನಲ್ಲಿ ಫ್ಲಟರ್ ಮತ್ತು bundletool ಸ್ಥಾಪಿಸಿ.'
                  : 'Install Flutter and bundletool in Termux for real APK building.',
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(s ? 'ಅರ್ಥವಾಯಿತು' : 'Got it'),
          ),
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  final IconData icon;

  const _SectionHeader({
    required this.title,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return Padding(
      padding: const EdgeInsets.only(left: 8, bottom: 8),
      child: Row(
        children: [
          Icon(icon, size: 20, color: theme.colorScheme.primary),
          const SizedBox(width: 8),
          Text(
            title,
            style: theme.textTheme.titleSmall?.copyWith(
              color: theme.colorScheme.primary,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}

class _HelpItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final String description;

  const _HelpItem({
    required this.icon,
    required this.title,
    required this.description,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: theme.colorScheme.primaryContainer,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(
            icon,
            size: 20,
            color: theme.colorScheme.onPrimaryContainer,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: theme.textTheme.bodyLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                description,
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onSurface.withOpacity(0.7),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
