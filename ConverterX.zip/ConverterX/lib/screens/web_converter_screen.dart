import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_colorpicker/flutter_colorpicker.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';
import '../models/web_app_config.dart';
import '../services/build_service.dart';
import '../services/file_service.dart';
import '../services/storage_service.dart';
import '../utils/validators.dart';
import '../utils/helpers.dart';
import '../widgets/custom_button.dart';
import '../widgets/custom_text_field.dart';
import '../widgets/loading_overlay.dart';

class WebConverterScreen extends StatefulWidget {
  const WebConverterScreen({super.key});

  @override
  State<WebConverterScreen> createState() => _WebConverterScreenState();
}

class _WebConverterScreenState extends State<WebConverterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _urlController = TextEditingController();
  final _appNameController = TextEditingController();
  final _packageController = TextEditingController(text: 'com.example.converter');
  
  final BuildService _buildService = BuildService();
  final FileService _fileService = FileService();
  final StorageService _storage = StorageService();
  
  Color _splashColor = const Color(0xFF6750A4);
  File? _selectedIcon;
  bool _isBuilding = false;
  String? _buildResult;

  @override
  void dispose() {
    _urlController.dispose();
    _appNameController.dispose();
    _packageController.dispose();
    super.dispose();
  }

  Future<void> _pickIcon() async {
    try {
      final file = await _fileService.pickImage();
      if (file != null) {
        setState(() => _selectedIcon = file);
        Helpers.showToast(
          context.read<ThemeProvider>().isKannada 
            ? 'ಐಕಾನ್ ಆಯ್ಕೆಮಾಡಲಾಗಿದೆ!' 
            : 'Icon selected!'
        );
      }
    } catch (e) {
      Helpers.showToast('Error: $e', isError: true);
    }
  }

  Future<void> _pickColor() async {
    final provider = context.read<ThemeProvider>();
    final s = provider.isKannada;
    
    Color pickedColor = _splashColor;
    
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(s ? 'ಬಣ್ಣ ಆಯ್ಕೆಮಾಡಿ' : 'Pick a Color'),
        content: SingleChildScrollView(
          child: ColorPicker(
            pickerColor: _splashColor,
            onColorChanged: (color) => pickedColor = color,
            pickerAreaHeightPercent: 0.8,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(s ? 'ರದ್ದು' : 'Cancel'),
          ),
          TextButton(
            onPressed: () {
              setState(() => _splashColor = pickedColor);
              Navigator.pop(context);
            },
            child: Text(s ? 'ಆಯ್ಕೆ' : 'Select'),
          ),
        ],
      ),
    );
  }

  Future<void> _buildApk() async {
    if (!_formKey.currentState!.validate()) return;

    final hasPermission = await _storage.requestStoragePermission();
    if (!hasPermission) {
      Helpers.showToast(
        context.read<ThemeProvider>().isKannada
          ? 'ಸಂಗ್ರಹ ಅನುಮತಿ ಅಗತ್ಯವಿದೆ'
          : 'Storage permission required',
        isError: true,
      );
      return;
    }

    setState(() => _isBuilding = true);

    try {
      final config = WebAppConfig(
        url: _urlController.text.trim(),
        appName: _appNameController.text.trim(),
        packageName: _packageController.text.trim(),
        splashColor: _splashColor,
        iconFile: _selectedIcon,
      );

      final result = await _buildService.buildWebApk(config);

      setState(() {
        _isBuilding = false;
        _buildResult = result.message;
      });

      if (result.success) {
        _showSuccessDialog(result);
      } else {
        Helpers.showToast(result.message, isError: true);
      }
    } catch (e) {
      setState(() => _isBuilding = false);
      Helpers.showToast('Error: $e', isError: true);
    }
  }

  void _showSuccessDialog(dynamic result) {
    final provider = context.read<ThemeProvider>();
    final s = provider.isKannada;
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        icon: const Icon(Icons.check_circle, color: Colors.green, size: 48),
        title: Text(s ? 'ಯಶಸ್ಸು!' : 'Success!'),
        content: Text(result.message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(s ? 'ಮುಚ್ಚಿ' : 'Close'),
          ),
          if (result.outputPath != null)
            FilledButton(
              onPressed: () {
                Navigator.pop(context);
                Helpers.shareFile(
                  result.outputPath,
                  'ConverterX Project: ${result.fileName}',
                );
              },
              child: Text(s ? 'ಹಂಚಿ' : 'Share'),
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final provider = context.watch<ThemeProvider>();
    final s = provider.isKannada;

    return Scaffold(
      appBar: AppBar(
        title: Text(s ? 'ವೆಬ್ ಟು ಆ್ಯಪ್' : 'Web to App'),
        centerTitle: true,
      ),
      body: LoadingOverlay(
        isLoading: _isBuilding,
        message: s ? 'APK ನಿರ್ಮಿಸಲಾಗುತ್ತಿದೆ...' : 'Building APK...',
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // URL Input
                CustomTextField(
                  controller: _urlController,
                  label: s ? 'ವೆಬ್ಸೈಟ್ URL' : 'Website URL',
                  hint: 'https://example.com',
                  prefixIcon: Icons.link,
                  keyboardType: TextInputType.url,
                  validator: Validators.validateUrl,
                ),
                
                const SizedBox(height: 20),
                
                // App Name
                CustomTextField(
                  controller: _appNameController,
                  label: s ? 'ಆ್ಯಪ್ ಹೆಸರು' : 'App Name',
                  hint: s ? 'ನನ್ನ ಆ್ಯಪ್' : 'My App',
                  prefixIcon: Icons.app_shortcut,
                  validator: Validators.validateAppName,
                ),
                
                const SizedBox(height: 20),
                
                // Package Name
                CustomTextField(
                  controller: _packageController,
                  label: s ? 'ಪ್ಯಾಕೇಜ್ ಹೆಸರು' : 'Package Name',
                  hint: 'com.example.app',
                  prefixIcon: Icons.code,
                  helperText: s 
                    ? 'Format: com.company.app' 
                    : 'Format: com.company.app',
                  validator: Validators.validatePackageName,
                ),
                
                const SizedBox(height: 24),
                
                // Appearance Section
                Text(
                  s ? 'ಗೋಚರತೆ' : 'Appearance',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 16),
                
                // Splash Color
                Card(
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: _splashColor,
                      child: const Icon(Icons.color_lens, color: Colors.white),
                    ),
                    title: Text(s ? 'ಸ್ಪ್ಲ್ಯಾಶ್ ಬಣ್ಣ' : 'Splash Color'),
                    subtitle: Text(
                      '#${_splashColor.value.toRadixString(16).substring(2).toUpperCase()}',
                    ),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: _pickColor,
                  ),
                ),
                
                const SizedBox(height: 12),
                
                // App Icon
                Card(
                  child: ListTile(
                    leading: _selectedIcon != null
                        ? ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: Image.file(
                              _selectedIcon!,
                              width: 40,
                              height: 40,
                              fit: BoxFit.cover,
                            ),
                          )
                        : const CircleAvatar(
                            child: Icon(Icons.image),
                          ),
                    title: Text(s ? 'ಆ್ಯಪ್ ಐಕಾನ್' : 'App Icon'),
                    subtitle: Text(
                      _selectedIcon != null
                          ? (s ? 'ಐಕಾನ್ ಆಯ್ಕೆಮಾಡಲಾಗಿದೆ' : 'Icon selected')
                          : (s ? 'ಐಕಾನ್ ಆಯ್ಕೆಮಾಡಿ' : 'Select an icon'),
                    ),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: _pickIcon,
                  ),
                ),
                
                const SizedBox(height: 32),
                
                // Preview Card
                if (_urlController.text.isNotEmpty && _appNameController.text.isNotEmpty)
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            s ? 'ಮುನ್ನೋಟ' : 'Preview',
                            style: theme.textTheme.titleSmall?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 12),
                          Row(
                            children: [
                              Container(
                                width: 48,
                                height: 48,
                                decoration: BoxDecoration(
                                  color: _splashColor,
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: _selectedIcon != null
                                    ? ClipRRect(
                                        borderRadius: BorderRadius.circular(12),
                                        child: Image.file(
                                          _selectedIcon!,
                                          fit: BoxFit.cover,
                                        ),
                                      )
                                    : const Icon(
                                        Icons.android,
                                        color: Colors.white,
                                      ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      _appNameController.text,
                                      style: theme.textTheme.bodyLarge?.copyWith(
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    Text(
                                      _urlController.text,
                                      style: theme.textTheme.bodySmall?.copyWith(
                                        color: theme.colorScheme.onSurface.withOpacity(0.6),
                                      ),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                
                const SizedBox(height: 32),
                
                // Build Button
                GradientButton(
                  text: s ? 'APK ನಿರ್ಮಿಸಿ' : 'Build APK',
                  icon: Icons.build,
                  isLoading: _isBuilding,
                  onPressed: _buildApk,
                ),
                
                const SizedBox(height: 16),
                
                // Note
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: theme.colorScheme.primaryContainer.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        Icons.info_outline,
                        color: theme.colorScheme.primary,
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          s
                            ? 'ಇದು ಫ್ಲಟರ್ ಪ್ರಾಜೆಕ್ಟ್ ಫೈಲ್‌ಗಳನ್ನು ರಚಿಸುತ್ತದೆ. APK ನಿರ್ಮಿಸಲು ಟರ್ಮಕ್ಸ್ ಅಥವಾ ಆನ್‌ಲೈನ್ ಸೇವೆಯನ್ನು ಬಳಸಿ.'
                            : 'This generates Flutter project files. Use Termux or an online service to build the APK.',
                          style: theme.textTheme.bodySmall,
                        ),
                      ),
                    ],
                  ),
                ),
                
                const SizedBox(height: 32),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
