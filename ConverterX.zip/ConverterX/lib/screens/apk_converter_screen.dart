import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';
import '../services/build_service.dart';
import '../services/file_service.dart';
import '../services/storage_service.dart';
import '../utils/helpers.dart';
import '../widgets/custom_button.dart';
import '../widgets/loading_overlay.dart';

class ApkConverterScreen extends StatefulWidget {
  const ApkConverterScreen({super.key});

  @override
  State<ApkConverterScreen> createState() => _ApkConverterScreenState();
}

class _ApkConverterScreenState extends State<ApkConverterScreen> {
  final BuildService _buildService = BuildService();
  final FileService _fileService = FileService();
  final StorageService _storage = StorageService();
  
  File? _selectedFile;
  String? _fileSize;
  bool _isConverting = false;
  String? _conversionResult;
  String? _outputPath;

  Future<void> _pickFile() async {
    try {
      final hasPermission = await _storage.requestStoragePermission();
      if (!hasPermission) {
        Helpers.showToast(
          context.read<ThemeProvider>().isKannada
            ? 'ಸಂಗ್ರಹ ಅನುಮತಿ ಅಗತ್ಯವಿದೆ'
            : 'Storage permission required',
          isError: true,
        );
        return;
      }

      final file = await _fileService.pickApkOrAab();
      if (file != null) {
        final size = await _fileService.getFileSize(file.path);
        setState(() {
          _selectedFile = file;
          _fileSize = _fileService.formatFileSize(size);
          _conversionResult = null;
          _outputPath = null;
        });
      }
    } catch (e) {
      Helpers.showToast('Error: $e', isError: true);
    }
  }

  Future<void> _convert() async {
    if
  Future<void> _convert() async {
    if (_selectedFile == null) {
      Helpers.showToast(
        context.read<ThemeProvider>().isKannada
          ? 'ದಯವಿಟ್ಟು ಫೈಲ್ ಆಯ್ಕೆಮಾಡಿ'
          : 'Please select a file first',
        isError: true,
      );
      return;
    }

    setState(() => _isConverting = true);

    try {
      final extension = _fileService.getFileExtension(_selectedFile!.path);
      dynamic result;

      if (extension.contains('apk')) {
        result = await _buildService.convertApkToAab(_selectedFile!.path);
      } else if (extension.contains('aab')) {
        result = await _buildService.convertAabToApk(_selectedFile!.path);
      } else {
        throw Exception('Unsupported file format');
      }

      setState(() {
        _isConverting = false;
        _conversionResult = result.message;
        _outputPath = result.outputPath;
      });

      if (result.success) {
        _showResultDialog(result);
      } else {
        Helpers.showToast(result.message, isError: true);
      }
    } catch (e) {
      setState(() => _isConverting = false);
      Helpers.showToast('Conversion failed: $e', isError: true);
    }
  }

  void _showResultDialog(dynamic result) {
    final provider = context.read<ThemeProvider>();
    final s = provider.isKannada;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        icon: Icon(
          result.success ? Icons.check_circle : Icons.error,
          color: result.success ? Colors.green : Colors.red,
          size: 48,
        ),
        title: Text(result.success 
          ? (s ? 'ಪರಿವರ್ತನೆ ಪೂರ್ಣ!' : 'Conversion Complete!') 
          : (s ? 'ವಿಫಲ' : 'Failed')
        ),
        content: SingleChildScrollView(
          child: Text(result.message),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(s ? 'ಮುಚ್ಚಿ' : 'Close'),
          ),
          if (result.outputPath != null)
            FilledButton.icon(
              onPressed: () {
                Navigator.pop(context);
                Helpers.shareFile(
                  result.outputPath,
                  'ConverterX Output: ${result.fileName}',
                );
              },
              icon: const Icon(Icons.share),
              label: Text(s ? 'ಹಂಚಿ' : 'Share'),
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final provider = context.watch<ThemeProvider>();
    final s = provider.isKannada;

    return Scaffold(
      appBar: AppBar(
        title: Text(s ? 'APK/AAB ಪರಿವರ್ತಕ' : 'APK/AAB Converter'),
        centerTitle: true,
      ),
      body: LoadingOverlay(
        isLoading: _isConverting,
        message: s ? 'ಪರಿವರ್ತಿಸಲಾಗುತ್ತಿದೆ...' : 'Converting...',
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Info Card
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(Icons.info_outline, color: theme.colorScheme.primary),
                          const SizedBox(width: 8),
                          Text(
                            s ? 'ಬಗ್ಗೆ' : 'About',
                            style: theme.textTheme.titleSmall?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        s
                          ? 'APK ಮತ್ತು AAB ಫೈಲ್‌ಗಳನ್ನು ಪರಸ್ಪರ ಪರಿವರ್ತಿಸಿ. ನಿಜವಾದ ಪರಿವರ್ತನೆಗೆ bundletool ಅಗತ್ಯವಿದೆ.'
                          : 'Convert between APK and AAB formats. True conversion requires bundletool.',
                        style: theme.textTheme.bodyMedium,
                      ),
                    ],
                  ),
                ),
              ),
              
              const SizedBox(height: 24),
              
              // File Selection Area
              Card(
                clipBehavior: Clip.antiAlias,
                child: InkWell(
                  onTap: _pickFile,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(32),
                    child: Column(
                      children: [
                        Icon(
                          _selectedFile != null 
                            ? (_fileService.getFileExtension(_selectedFile!.path).contains('apk') 
                                ? Icons.android 
                                : Icons.inventory_2)
                            : Icons.upload_file,
                          size: 64,
                          color: _selectedFile != null 
                            ? theme.colorScheme.primary 
                            : theme.colorScheme.onSurface.withOpacity(0.4),
                        ),
                        const SizedBox(height: 16),
                        Text(
                          _selectedFile != null
                            ? _fileService.getFileName(_selectedFile!.path)
                            : (s ? 'ಫೈಲ್ ಆಯ್ಕೆಮಾಡಿ' : 'Select File'),
                          style: theme.textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        if (_selectedFile != null && _fileSize != null) ...[
                          const SizedBox(height: 4),
                          Text(
                            _fileSize!,
                            style: theme.textTheme.bodySmall?.copyWith(
                              color: theme.colorScheme.onSurface.withOpacity(0.6),
                            ),
                          ),
                        ],
                        const SizedBox(height: 8),
                        Text(
                          s ? 'APK ಅಥವಾ AAB ಫೈಲ್' : 'APK or AAB file',
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: theme.colorScheme.onSurface.withOpacity(0.5),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              
              const SizedBox(height: 24),
              
              // Convert Button
              if (_selectedFile != null)
                CustomButton(
                  text: _fileService.getFileExtension(_selectedFile!.path).contains('apk')
                    ? (s ? 'AAB ಗೆ ಪರಿವರ್ತಿಸಿ' : 'Convert to AAB')
                    : (s ? 'APK ಗೆ ಪರಿವರ್ತಿಸಿ' : 'Convert to APK'),
                  icon: Icons.swap_horiz,
                  isLoading: _isConverting,
                  onPressed: _convert,
                ),
              
              const SizedBox(height: 24),
              
              // Instructions
              Text(
                s ? 'ಬಳಕೆಯ ವಿಧಾನ' : 'How to Use',
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 12),
              
              _InstructionStep(
                number: '1',
                title: s ? 'ಫೈಲ್ ಆಯ್ಕೆಮಾಡಿ' : 'Select File',
                description: s 
                  ? 'ನಿಮ್ಮ ಸಾಧನದಿಂದ APK ಅಥವಾ AAB ಫೈಲ್ ಆಯ್ಕೆಮಾಡಿ'
                  : 'Pick an APK or AAB file from your device',
              ),
              _InstructionStep(
                number: '2',
                title: s ? 'ಪರಿವರ್ತಿಸಿ' : 'Convert',
                description: s
                  ? 'ಪರಿವರ್ತನೆ ಪ್ರಕ್ರಿಯೆಯನ್ನು ಪ್ರಾರಂಭಿಸಲು ಬಟನ್ ಒತ್ತಿರಿ'
                  : 'Press the button to start conversion',
              ),
              _InstructionStep(
                number: '3',
                title: s ? 'ಫಲಿತಾಂಶ ಪಡೆಯಿರಿ' : 'Get Result',
                description: s
                  ? 'ಪರಿವರ್ತಿತ ಫೈಲ್ ಅನ್ನು ಹಂಚಿಕೊಳ್ಳಿ ಅಥವಾ ಸಂಗ್ರಹಿಸಿ'
                  : 'Share or save the converted file',
              ),
              
              const SizedBox(height: 24),
              
              // Bundletool Note
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: theme.colorScheme.tertiaryContainer.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: theme.colorScheme.tertiary.withOpacity(0.3),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(
                          Icons.terminal,
                          color: theme.colorScheme.tertiary,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          s ? 'ಟರ್ಮಕ್ಸ್‌ನಲ್ಲಿ bundletool' : 'bundletool in Termux',
                          style: theme.textTheme.titleSmall?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      s
                        ? 'ನಿಜವಾದ ಪರಿವರ್ತನೆಗಾಗಿ ಟರ್ಮಕ್ಸ್‌ನಲ್ಲಿ ಈ ಆಜ್ಞೆಗಳನ್ನು ಚಲಾಯಿಸಿ:'
                        : 'For true conversion, run these commands in Termux:',
                      style: theme.textTheme.bodySmall,
                    ),
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: theme.colorScheme.surface,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: SelectableText(
                        '# Install bundletool\npkg install bundletool\n\n# APK to AAB\nbundletool build-bundle --modules=input.apk --output=output.aab\n\n# AAB to APK\nbundletool build-apks --bundle=input.aab --output=output.apks --mode=universal',
                        style: TextStyle(
                          fontFamily: 'monospace',
                          fontSize: 12,
                          color: theme.colorScheme.onSurface,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              
              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }
}

class _InstructionStep extends StatelessWidget {
  final String number;
  final String title;
  final String description;

  const _InstructionStep({
    required this.number,
    required this.title,
    required this.description,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 28,
            height: 28,
            decoration: BoxDecoration(
              color: theme.colorScheme.primary,
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                number,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: theme.textTheme.bodyLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  description,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: theme.colorScheme.onSurface.withOpacity(0.7),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
