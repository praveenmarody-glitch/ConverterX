import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';
import '../constants/app_colors.dart';
import '../widgets/custom_button.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final provider = context.watch<ThemeProvider>();
    
    final s = provider.isKannada;
    
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          // App Bar
          SliverAppBar(
            expandedHeight: 200,
            floating: false,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              title: Text(
                s ? 'ಕನ್ವರ್ಟರ್X' : 'ConverterX',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              background: Container(
                decoration: const BoxDecoration(
                  gradient: AppColors.primaryGradient,
                ),
                child: Center(
                  child: Icon(
                    Icons.swap_horiz_rounded,
                    size: 80,
                    color: Colors.white.withOpacity(0.3),
                  ),
                ),
              ),
            ),
          ),
          
          // Content
          SliverPadding(
            padding: const EdgeInsets.all(20),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                // Welcome Card
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          s ? 'ಸ್ವಾಗತ!' : 'Welcome!',
                          style: theme.textTheme.headlineSmall?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          s 
                            ? 'ವೆಬ್ಸೈಟ್‌ಗಳನ್ನು ಆ್ಯಪ್‌ಗಳಾಗಿ ಪರಿವರ್ತಿಸಿ ಮತ್ತು APK/AAB ಫೈಲ್‌ಗಳನ್ನು ನಿರ್ವಹಿಸಿ.'
                            : 'Convert websites to apps and manage APK/AAB files easily.',
                          style: theme.textTheme.bodyMedium?.copyWith(
                            color: theme.colorScheme.onSurface.withOpacity(0.7),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                
                const SizedBox(height: 24),
                
                // Main Actions
                Text(
                  s ? 'ಮುಖ್ಯ ವೈಶಿಷ್ಟ್ಯಗಳು' : 'Main Features',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 16),
                
                // Web to App Button
                _FeatureCard(
                  icon: Icons.language_rounded,
                  title: s ? 'ವೆಬ್ ಟು ಆ್ಯಪ್' : 'Web to App',
                  subtitle: s 
                    ? 'ಯಾವುದೇ ವೆಬ್ಸೈಟ್‌ನ್ನು ಆ್ಯಪ್‌ ಆಗಿ ಪರಿವರ್ತಿಸಿ'
                    : 'Convert any website into a mobile app',
                  gradient: AppColors.primaryGradient,
                  onTap: () {
                    // Navigate to Web Converter tab
                    DefaultTabController.of(context)?.animateTo(1);
                  },
                ),
                
                const SizedBox(height: 16),
                
                // APK/AAB Converter Button
                _FeatureCard(
                  icon: Icons.swap_horiz_rounded,
                  title: s ? 'APK/AAB ಪರಿವರ್ತಕ' : 'APK/AAB Converter',
                  subtitle: s
                    ? 'APK ಮತ್ತು AAB ಫೈಲ್‌ಗಳನ್ನು ಪರಿವರ್ತಿಸಿ'
                    : 'Convert between APK and AAB formats',
                  gradient: AppColors.successGradient,
                  onTap: () {
                    // Navigate to Converter tab
                    DefaultTabController.of(context)?.animateTo(2);
                  },
                ),
                
                const SizedBox(height: 24),
                
                // Quick Stats
                Text(
                  s ? 'ತ್ವರಿತ ಮಾರ್ಗದರ್ಶಿ' : 'Quick Guide',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 16),
                
                _GuideStep(
                  number: '1',
                  title: s ? 'URL ನಮೂದಿಸಿ' : 'Enter URL',
                  description: s 
                    ? 'ನೀವು ಪರಿವರ್ತಿಸಲು ಬಯಸುವ ವೆಬ್ಸೈಟ್ URL ನಮೂದಿಸಿ'
                    : 'Enter the website URL you want to convert',
                ),
                _GuideStep(
                  number: '2',
                  title: s ? 'ಆ್ಯಪ್ ಸೆಟ್ಟಿಂಗ್ಸ್' : 'App Settings',
                  description: s
                    ? 'ಆ್ಯಪ್ ಹೆಸರು, ಐಕಾನ್ ಮತ್ತು ಬಣ್ಣವನ್ನು ಕಸ್ಟಮೈಸ್ ಮಾಡಿ'
                    : 'Customize app name, icon, and colors',
                ),
                _GuideStep(
                  number: '3',
                  title: s ? 'APK ನಿರ್ಮಿಸಿ' : 'Build APK',
                  description: s
                    ? 'ಒಂದು ಕ್ಲಿಕ್‌ನಲ್ಲಿ ನಿಮ್ಮ ಆ್ಯಪ್ ನಿರ್ಮಿಸಿ'
                    : 'Build your app with one click',
                ),
                
                const SizedBox(height: 32),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}

class _FeatureCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Gradient gradient;
  final VoidCallback onTap;

  const _FeatureCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.gradient,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            gradient: gradient,
          ),
          padding: const EdgeInsets.all(20),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  icon,
                  color: Colors.white,
                  size: 32,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.9),
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(
                Icons.arrow_forward_ios,
                color: Colors.white,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _GuideStep extends StatelessWidget {
  final String number;
  final String title;
  final String description;

  const _GuideStep({
    required this.number,
    required this.title,
    required this.description,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: theme.colorScheme.primaryContainer,
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                number,
                style: TextStyle(
                  color: theme.colorScheme.onPrimaryContainer,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: theme.textTheme.bodyLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  description,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: theme.colorScheme.onSurface.withOpacity(0.7),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
