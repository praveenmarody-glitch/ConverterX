class Validators {
  static bool isValidUrl(String url) {
    if (url.isEmpty) return false;
    final uri = Uri.tryParse(url);
    return uri != null && (uri.scheme == 'http' || uri.scheme == 'https');
  }

  static bool isValidPackageName(String packageName) {
    if (packageName.isEmpty) return false;
    final regex = RegExp(r'^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$');
    return regex.hasMatch(packageName);
  }

  static bool isValidAppName(String name) {
    return name.trim().length >= 2 && name.trim().length <= 50;
  }

  static String? validateUrl(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter a URL';
    }
    if (!isValidUrl(value)) {
      return 'Please enter a valid URL (http:// or https://)';
    }
    return null;
  }

  static String? validatePackageName(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter a package name';
    }
    if (!isValidPackageName(value)) {
      return 'Use format: com.example.app';
    }
    return null;
  }

  static String? validateAppName(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter an app name';
    }
    if (!isValidAppName(value)) {
      return 'App name must be 2-50 characters';
    }
    return null;
  }
}
