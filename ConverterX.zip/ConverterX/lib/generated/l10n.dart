import 'package:flutter/material.dart';

class S {
  static const AppLocalizationDelegate delegate = AppLocalizationDelegate();

  static S? _current;
  static S get current => _current!;

  static S of(BuildContext context) {
    return Localizations.of<S>(context, S) ?? S();
  }

  // English strings
  String get appName => 'ConverterX';
  String get webToApp => 'Web to App';
  String get apkAabConverter => 'APK/AAB Converter';
  String get enterUrl => 'Enter Website URL';
  String get buildApk => 'Build APK';
  String get settings => 'Settings';
  String get darkMode => 'Dark Mode';
  String get language => 'Language';
  String get english => 'English';
  String get kannada => 'Kannada';
  String get great => 'Great! Very Good';
  String get success => 'Success!';
  String get error => 'Error';
  String get pickFile => 'Pick File';
  String get convert => 'Convert';
  String get download => 'Download';
  String get howToUse => 'How to Use';
  String get about => 'About';
  String get version => 'Version 1.0.0';
  String get invalidUrl => 'Please enter a valid URL';
  String get invalidPackage => 'Invalid package name format';
  String get storagePermission => 'Storage permission required';
  String get selectApkOrAab => 'Select APK or AAB file';
  String get converting => 'Converting...';
  String get conversionComplete => 'Conversion Complete!';
  String get building => 'Building...';
  String get appNameLabel => 'App Name';
  String get packageName => 'Package Name';
  String get splashColor => 'Splash Screen Color';
  String get selectIcon => 'Select App Icon';
}

class AppLocalizationDelegate extends LocalizationsDelegate<S> {
  const AppLocalizationDelegate();

  @override
  bool isSupported(Locale locale) => ['en', 'kn'].contains(locale.languageCode);

  @override
  Future<S> load(Locale locale) async {
    S._current = S();
    return S();
  }

  @override
  bool shouldReload(AppLocalizationDelegate old) => false;

  List<Locale> get supportedLocales => const [
    Locale('en'),
    Locale('kn'),
  ];
}
