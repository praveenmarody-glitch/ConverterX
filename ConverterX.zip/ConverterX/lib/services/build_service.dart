import 'dart:io';
import 'package:archive/archive.dart';
import 'package:archive/archive_io.dart';
import 'package:path/path.dart' as path;
import '../models/web_app_config.dart';
import '../models/conversion_result.dart';
import 'storage_service.dart';
import 'file_service.dart';

class BuildService {
  final StorageService _storage = StorageService();
  final FileService _fileService = FileService();

  /// Simulates building a WebView APK from a URL
  /// In production, this would generate actual Flutter project files
  Future<ConversionResult> buildWebApk(WebAppConfig config) async {
    try {
      // Validate inputs
      if (!_isValidUrl(config.url)) {
        return ConversionResult.error('Invalid URL format');
      }

      if (!_isValidPackageName(config.packageName)) {
        return ConversionResult.error('Invalid package name. Use format: com.example.app');
      }

      // Simulate build process with delays
      await Future.delayed(const Duration(seconds: 1)); // Analyzing
      await Future.delayed(const Duration(seconds: 2)); // Generating code
      await Future.delayed(const Duration(seconds: 2)); // Building

      // Create project structure
      final projectsDir = await _storage.getProjectsDirectory();
      final projectName = config.appName.toLowerCase().replaceAll(' ', '_');
      final projectDir = Directory('${projectsDir.path}/$projectName');
      
      if (await projectDir.exists()) {
        await projectDir.delete(recursive: true);
      }
      await projectDir.create(recursive: true);

      // Generate Flutter project files
      await _generateProjectFiles(projectDir, config);

      // Create a ZIP of the project for user to build
      final zipPath = '${projectDir.path}.zip';
      await _createZip(projectDir, zipPath);

      return ConversionResult.success(
        message: 'Project generated successfully!\n\n'
            'Next steps:\n'
            '1. Extract the ZIP file\n'
            '2. Open in Termux or Android Studio\n'
            '3. Run: flutter build apk --release\n\n'
            'The project includes WebView setup for:\n${config.url}',
        outputPath: zipPath,
        fileName: '$projectName.zip',
      );
    } catch (e) {
      return ConversionResult.error('Build failed: $e');
    }
  }

  /// Converts APK to AAB using bundletool simulation
  Future<ConversionResult> convertApkToAab(String apkPath) async {
    try {
      if (!_fileService.getFileExtension(apkPath).contains('apk')) {
        return ConversionResult.error('Please select a valid APK file');
      }

      await Future.delayed(const Duration(seconds: 2)); // Processing

      final downloadsDir = await _storage.getDownloadsDirectory();
      final baseName = path.basenameWithoutExtension(apkPath);
      final aabPath = '${downloadsDir.path}/${baseName}_converted.aab';

      // In a real implementation, this would use bundletool
      // For now, we create a placeholder and provide instructions
      final aabFile = File(aabPath);
      await aabFile.writeAsString(
        '# AAB Conversion Placeholder\n\n'
        'To convert APK to AAB using bundletool:\n\n'
        '1. Install bundletool in Termux:\n'
        '   pkg install bundletool\n\n'
        '2. Run:\n'
        '   bundletool build-bundle --modules=$apkPath --output=$aabPath\n\n'
        '3. Or use Android Studio:\n'
        '   Build > Generate Signed Bundle/APK\n\n'
        'Original APK: $apkPath\n',
      );

      return ConversionResult.success(
        message: 'AAB conversion prepared!\n\n'
            'Note: True APK→AAB conversion requires bundletool.\n'
            'Instructions have been saved with the output file.',
        outputPath: aabPath,
        fileName: '${baseName}_converted.aab',
      );
    } catch (e) {
      return ConversionResult.error('Conversion failed: $e');
    }
  }

  /// Converts AAB to APK using bundletool simulation
  Future<ConversionResult> convertAabToApk(String aabPath) async {
    try {
      if (!_fileService.getFileExtension(aabPath).contains('aab')) {
        return ConversionResult.error('Please select a valid AAB file');
      }

      await Future.delayed(const Duration(seconds: 2)); // Processing

      final downloadsDir = await _storage.getDownloadsDirectory();
      final baseName = path.basenameWithoutExtension(aabPath);
      final apksPath = '${downloadsDir.path}/${baseName}_converted.apks';

      // Create instructions file
      final apksFile = File(apksPath);
      await apksFile.writeAsString(
        '# AAB to APK Conversion Instructions\n\n'
        'To convert AAB to APK using bundletool:\n\n'
        '1. Install bundletool in Termux:\n'
        '   pkg install bundletool\n\n'
        '2. Build universal APK:\n'
        '   bundletool build-apks --bundle=$aabPath --output=$apksPath --mode=universal\n\n'
        '3. Extract APK from APKS:\n'
        '   unzip $apksPath -d output/\n\n'
        '4. The universal APK will be in output/universal.apk\n\n'
        'Original AAB: $aabPath\n',
      );

      return ConversionResult.success(
        message: 'APK conversion prepared!\n\n'
            'Note: True AAB→APK conversion requires bundletool.\n'
            'Instructions have been saved with the output file.',
        outputPath: apksPath,
        fileName: '${baseName}_converted.apks',
      );
    } catch (e) {
      return ConversionResult.error('Conversion failed: $e');
    }
  }

  Future<void> _generateProjectFiles(Directory projectDir, WebAppConfig config) async {
    // Generate main.dart
    final mainDart = '''
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

void main() {
  runApp(const ${config.appName.replaceAll(' ', '')}App());
}

class ${config.appName.replaceAll(' ', '')}App extends StatelessWidget {
  const ${config.appName.replaceAll(' ', '')}App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '${config.appName}',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: Color(${config.splashColor.value})),
      ),
      home: const SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 2), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const WebViewScreen()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(${config.splashColor.value}),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const CircularProgressIndicator(color: Colors.white),
            const SizedBox(height: 20),
            Text(
              '${config.appName}',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class WebViewScreen extends StatefulWidget {
  const WebViewScreen({super.key});

  @override
  State<WebViewScreen> createState() => _WebViewScreenState();
}

class _WebViewScreenState extends State<WebViewScreen> {
  late final WebViewController controller;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (_) => setState(() => isLoading = true),
          onPageFinished: (_) => setState(() => isLoading = false),
        ),
      )
      ..loadRequest(Uri.parse('${config.url}'));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('${config.appName}'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => controller.reload(),
          ),
        ],
      ),
      body: Stack(
        children: [
          WebViewWidget(controller: controller),
          if (isLoading)
            const Center(child: CircularProgressIndicator()),
        ],
      ),
    );
  }
}
''';

    await _fileService.writeFile('${projectDir.path}/lib/main.dart', mainDart);

    // Generate pubspec.yaml
    final pubspec = '''
name: ${config.appName.toLowerCase().replaceAll(' ', '_')}
description: WebView app for ${config.url}
publish_to: 'none'
version: 1.0.0+1

environment:
  sdk: '>=3.0.0 <4.0.0'

dependencies:
  flutter:
    sdk: flutter
  webview_flutter: ^4.4.2
  cupertino_icons: ^1.0.6

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^3.0.1

flutter:
  uses-material-design: true
''';

    await _fileService.writeFile('${projectDir.path}/pubspec.yaml', pubspec);

    // Generate AndroidManifest.xml
    final manifest = '''
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-permission android:name="android.permission.INTERNET" />
    <application
        android:label="${config.appName}"
        android:name="\${applicationName}"
        android:icon="@mipmap/ic_launcher">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTop"
            android:theme="@style/LaunchTheme"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|smallestScreenSize|locale|layoutDirection|fontScale|screenLayout|density|uiMode"
            android:hardwareAccelerated="true"
            android:windowSoftInputMode="adjustResize">
            <meta-data
              android:name="io.flutter.embedding.android.NormalTheme"
              android:resource="@style/NormalTheme"
              />
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity>
        <meta-data
            android:name="flutterEmbedding"
            android:value="2" />
    </application>
</manifest>
''';

    final androidDir = Directory('${projectDir.path}/android/app/src/main');
    await androidDir.create(recursive: true);
    await _fileService.writeFile('${androidDir.path}/AndroidManifest.xml', manifest);
  }

  Future<void> _createZip(Directory sourceDir, String zipPath) async {
    final encoder = ZipFileEncoder();
    encoder.create(zipPath);
    await encoder.addDirectory(sourceDir);
    encoder.close();
  }

  bool _isValidUrl(String url) {
    final uri = Uri.tryParse(url);
    return uri != null && (uri.scheme == 'http' || uri.scheme == 'https');
  }

  bool _isValidPackageName(String packageName) {
    final regex = RegExp(r'^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$');
    return regex.hasMatch(packageName);
  }
}
