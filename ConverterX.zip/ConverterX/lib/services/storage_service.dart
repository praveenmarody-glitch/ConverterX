import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:permission_handler/permission_handler.dart';

class StorageService {
  static final StorageService _instance = StorageService._internal();
  factory StorageService() => _instance;
  StorageService._internal();

  Future<bool> requestStoragePermission() async {
    if (Platform.isAndroid) {
      final status = await Permission.storage.request();
      if (status.isGranted) return true;
      
      // For Android 13+
      final photos = await Permission.photos.request();
      final videos = await Permission.videos.request();
      final audio = await Permission.audio.request();
      
      return photos.isGranted || videos.isGranted || audio.isGranted;
    }
    return true;
  }

  Future<bool> requestManageStorage() async {
    if (Platform.isAndroid) {
      final status = await Permission.manageExternalStorage.request();
      return status.isGranted;
    }
    return true;
  }

  Future<Directory> getAppDirectory() async {
    final dir = await getApplicationDocumentsDirectory();
    final appDir = Directory('${dir.path}/ConverterX');
    if (!await appDir.exists()) {
      await appDir.create(recursive: true);
    }
    return appDir;
  }

  Future<Directory> getDownloadsDirectory() async {
    final appDir = await getAppDirectory();
    final downloads = Directory('${appDir.path}/Downloads');
    if (!await downloads.exists()) {
      await downloads.create(recursive: true);
    }
    return downloads;
  }

  Future<Directory> getProjectsDirectory() async {
    final appDir = await getAppDirectory();
    final projects = Directory('${appDir.path}/Projects');
    if (!await projects.exists()) {
      await projects.create(recursive: true);
    }
    return projects;
  }

  Future<void> savePreference(String key, String value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(key, value);
  }

  Future<String?> getPreference(String key) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(key);
  }

  Future<void> clearAll() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  }
}
