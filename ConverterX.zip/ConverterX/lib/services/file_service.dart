import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as path;
import 'storage_service.dart';

class FileService {
  final StorageService _storage = StorageService();
  final ImagePicker _imagePicker = ImagePicker();

  Future<File?> pickApkOrAab() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['apk', 'aab'],
        allowMultiple: false,
      );
      
      if (result != null && result.files.single.path != null) {
        return File(result.files.single.path!);
      }
      return null;
    } catch (e) {
      throw Exception('Failed to pick file: $e');
    }
  }

  Future<File?> pickImage() async {
    try {
      final source = await _showImageSourceDialog();
      if (source == null) return null;

      final XFile? pickedFile = source == ImageSource.camera
          ? await _imagePicker.pickImage(source: ImageSource.camera, imageQuality: 85)
          : await _imagePicker.pickImage(source: ImageSource.gallery, imageQuality: 85);

      if (pickedFile != null) {
        return File(pickedFile.path);
      }
      return null;
    } catch (e) {
      throw Exception('Failed to pick image: $e');
    }
  }

  Future<ImageSource?> _showImageSourceDialog() async {
    // This will be handled by the UI layer
    // Returning gallery as default for now
    return ImageSource.gallery;
  }

  Future<File> copyToAppDirectory(File sourceFile, String subFolder) async {
    final appDir = await _storage.getAppDirectory();
    final targetDir = Directory('${appDir.path}/$subFolder');
    
    if (!await targetDir.exists()) {
      await targetDir.create(recursive: true);
    }

    final fileName = path.basename(sourceFile.path);
    final targetPath = '${targetDir.path}/$fileName';
    
    return sourceFile.copy(targetPath);
  }

  Future<String> readFileAsString(String filePath) async {
    final file = File(filePath);
    if (await file.exists()) {
      return await file.readAsString();
    }
    throw Exception('File not found: $filePath');
  }

  Future<void> writeFile(String filePath, String content) async {
    final file = File(filePath);
    await file.writeAsString(content);
  }

  Future<void> deleteFile(String filePath) async {
    final file = File(filePath);
    if (await file.exists()) {
      await file.delete();
    }
  }

  String getFileExtension(String filePath) {
    return path.extension(filePath).toLowerCase();
  }

  String getFileName(String filePath) {
    return path.basename(filePath);
  }

  Future<int> getFileSize(String filePath) async {
    final file = File(filePath);
    if (await file.exists()) {
      return await file.length();
    }
    return 0;
  }

  String formatFileSize(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    if (bytes < 1024 * 1024 * 1024) {
      return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    }
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
  }
}
