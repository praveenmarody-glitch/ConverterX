import 'package:flutter/material.dart';

class BuildProgressDialog extends StatefulWidget {
  final Stream<String> progressStream;
  final VoidCallback onCancel;

  const BuildProgressDialog({
    super.key,
    required this.progressStream,
    required this.onCancel,
  });

  @override
  State<BuildProgressDialog> createState() => _BuildProgressDialogState();
}

class _BuildProgressDialogState extends State<BuildProgressDialog>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  String _currentStep = 'Initializing...';
  double _progress = 0.0;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat();

    widget.progressStream.listen((step) {
      if (mounted) {
        setState(() {
          _currentStep = step;
          _progress += 0.25;
          if (_progress > 1.0) _progress = 1.0;
        });
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return AlertDialog(
      title: Text(
        'Building APK...',
        style: theme.textTheme.titleLarge,
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          RotationTransition(
            turns: _controller,
            child: const Icon(
              Icons.settings,
              size: 48,
              color: Colors.blue,
            ),
          ),
          const SizedBox(height: 24),
          LinearProgressIndicator(
            value: _progress,
            backgroundColor: Colors.grey.shade200,
            valueColor: AlwaysStoppedAnimation<Color>(theme.colorScheme.primary),
          ),
          const SizedBox(height: 16),
          Text(
            _currentStep,
            textAlign: TextAlign.center,
            style: theme.textTheme.bodyMedium,
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: widget.onCancel,
          child: const Text('Cancel'),
        ),
      ],
    );
  }
}
