import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';

class LanguageSelector extends StatelessWidget {
  const LanguageSelector({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<ThemeProvider>(
      builder: (context, provider, child) {
        return SegmentedButton<String>(
          segments: const [
            ButtonSegment(
              value: 'en',
              label: Text('English'),
              icon: Icon(Icons.language),
            ),
            ButtonSegment(
              value: 'kn',
              label: Text('ಕನ್ನಡ'),
              icon: Icon(Icons.language),
            ),
          ],
          selected: {provider.locale.languageCode},
          onSelectionChanged: (Set<String> newSelection) {
            provider.setLocale(newSelection.first);
          },
        );
      },
    );
  }
}
