class ConversionResult {
  final bool success;
  final String message;
  final String? outputPath;
  final String? fileName;
  final DateTime timestamp;

  ConversionResult({
    required this.success,
    required this.message,
    this.outputPath,
    this.fileName,
    DateTime? timestamp,
  }) : timestamp = timestamp ?? DateTime.now();

  factory ConversionResult.success({
    required String message,
    String? outputPath,
    String? fileName,
  }) {
    return ConversionResult(
      success: true,
      message: message,
      outputPath: outputPath,
      fileName: fileName,
    );
  }

  factory ConversionResult.error(String message) {
    return ConversionResult(
      success: false,
      message: message,
    );
  }
}
