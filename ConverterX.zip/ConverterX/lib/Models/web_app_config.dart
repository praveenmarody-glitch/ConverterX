import 'dart:io';

class WebAppConfig {
  final String url;
  final String appName;
  final String packageName;
  final Color splashColor;
  final File? iconFile;

  WebAppConfig({
    required this.url,
    required this.appName,
    this.packageName = 'com.example.converter',
    this.splashColor = const Color(0xFF6750A4),
    this.iconFile,
  });

  Map<String, dynamic> toJson() => {
    'url': url,
    'appName': appName,
    'packageName': packageName,
    'splashColor': splashColor.value,
    'hasIcon': iconFile != null,
  };
}

// Re-export Color from material
import 'package:flutter/material.dart' show Color;
