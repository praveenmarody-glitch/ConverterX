import 'package:flutter/material.dart';

class AppColors {
  // Light Theme
  static const Color primaryLight = Color(0xFF6750A4);
  static const Color secondaryLight = Color(0xFF625B71);
  static const Color surfaceLight = Color(0xFFFFFBFE);
  static const Color backgroundLight = Color(0xFFFFFBFE);
  static const Color errorLight = Color(0xFFB3261E);

  // Dark Theme
  static const Color primaryDark = Color(0xFFD0BCFF);
  static const Color secondaryDark = Color(0xFFCCC2DC);
  static const Color surfaceDark = Color(0xFF1C1B1F);
  static const Color backgroundDark = Color(0xFF1C1B1F);
  static const Color errorDark = Color(0xFFF2B8B5);

  // Accent Colors
  static const Color success = Color(0xFF4CAF50);
  static const Color warning = Color(0xFFFFA726);
  static const Color info = Color(0xFF2196F3);
  
  // Gradients
  static const LinearGradient primaryGradient = LinearGradient(
    colors: [Color(0xFF6750A4), Color(0xFF9C27B0)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  static const LinearGradient successGradient = LinearGradient(
    colors: [Color(0xFF4CAF50), Color(0xFF8BC34A)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}
