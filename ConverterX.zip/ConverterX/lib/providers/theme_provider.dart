import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../constants/app_theme.dart';

class ThemeProvider extends ChangeNotifier {
  ThemeMode _themeMode = ThemeMode.system;
  Locale _locale = const Locale('en');
  
  ThemeMode get themeMode => _themeMode;
  Locale get locale => _locale;
  
  ThemeData get lightTheme => AppTheme.lightTheme;
  ThemeData get darkTheme => AppTheme.darkTheme;
  
  bool get isDarkMode => _themeMode == ThemeMode.dark;
  bool get isKannada => _locale.languageCode == 'kn';

  Future<void> loadTheme() async {
    final prefs = await SharedPreferences.getInstance();
    final themeIndex = prefs.getInt('theme_mode') ?? 0;
    final langCode = prefs.getString('language') ?? 'en';
    
    _themeMode = ThemeMode.values[themeIndex];
    _locale = Locale(langCode);
    notifyListeners();
  }

  Future<void> setThemeMode(ThemeMode mode) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('theme_mode', mode.index);
    _themeMode = mode;
    notifyListeners();
  }

  Future<void> toggleTheme() async {
    final newMode = isDarkMode ? ThemeMode.light : ThemeMode.dark;
    await setThemeMode(newMode);
  }

  Future<void> setLocale(String languageCode) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('language', languageCode);
    _locale = Locale(languageCode);
    notifyListeners();
  }

  Future<void> toggleLanguage() async {
    final newLang = isKannada ? 'en' : 'kn';
    await setLocale(newLang);
  }

  String getString(String en, String kn) {
    return isKannada ? kn : en;
  }
}
